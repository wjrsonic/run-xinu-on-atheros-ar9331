/* vlanStat.c - vlanStat */

#include <xinu.h>

int32 vlanStat(void)
{
    kprintf("Switch Core not found!\n");
    return SYSERR;
}
